module SING

enum SingMode { Stealth = 0, Defense = 1, Offense = 2 }

enum SingEvent {
  ModeSwitch = 0,
  Kill = 1,
  Idle = 2
}

enum SingJobKind {
  OpenDoor = 0,
  DisableCamera = 1,
  MemoryWipe = 2
}

public class SingJob {
  public let id: Int32;
  public let target: wref<GameObject>;
  public let kind: SingJobKind;
}

public class SingIdleCallback extends DelayCallback {
  public func Call() -> Void {
    let sys = SingSystem.Get(GetGameInstance());
    if IsDefined(sys) {
      sys.OnIdleTick();
    };
  }
}

public class SingJobCallback extends DelayCallback {
  public let jobId: Int32;

  public func Call() -> Void {
    let sys = SingSystem.Get(GetGameInstance());
    if IsDefined(sys) {
      sys.CompleteJob(this.jobId);
    };
  }
}

public class SingSystem extends ScriptableSystem {

public func IsInstalled() -> Bool {
  let game = this.GetGameInstance();
  let player = GameInstance.GetPlayerSystem(game).GetLocalPlayerMainGameObject();
  let ts = GameInstance.GetTransactionSystem(game);

  return ts.GetItemQuantity(player, ItemID.CreateQuery(t"Items.SingShard")) > 0;
}

  private persistent let m_mode: SingMode;
  private let m_lastSpoke: Float;
  private let m_idleRunning: Bool;
  private let m_cooldown: Float = 6.0;

  // job system state
  private let m_jobs: array<ref<SingJob>>;
  private let m_nextJobId: Int32;
  private let m_maxRange: Float = 25.0;

  // radius scan settings
  private let m_scanRadius: Float = 20.0;
  private let m_maxJobs: Int32 = 3;

  public func IsSavable() -> Bool = true

  public static func Get(game: GameInstance) -> ref<SingSystem> {
    return GameInstance.GetScriptableSystemsContainer(game)
      .Get(n"SING.SingSystem") as SingSystem;
  }

  public func CycleMode() -> Void {
    this.m_mode = IntEnum<SingMode>((EnumInt(this.m_mode) + 1) % 3);
    this.Trigger(SingEvent.ModeSwitch, true);
  }

  // sets a specific mode (the three quickhacks will call these)
  public func SetMode(mode: SingMode) -> Void {
    this.m_mode = mode;
    this.Trigger(SingEvent.ModeSwitch, true);
  }

  public func SetStealth() -> Void { this.SetMode(SingMode.Stealth); }
  public func SetDefense() -> Void { this.SetMode(SingMode.Defense); }
  public func SetOffense() -> Void { this.SetMode(SingMode.Offense); }

  // force = true ignores the cooldown (use for important lines)
public func Trigger(ev: SingEvent, opt force: Bool) -> Void {
  if !this.IsInstalled() {
    return;
  };

  let now = EngineTime.ToFloat(GameInstance.GetTimeSystem(this.GetGameInstance()).GetSimTime());

  if !force && this.m_lastSpoke > 0.0 && (now - this.m_lastSpoke) < this.m_cooldown {
    return;
  };

  this.m_lastSpoke = now;
  let line = this.PickLine(ev);
  if Equals(line, "") {
    return;
  };
  this.Say(line);
}
  private func PickLine(ev: SingEvent) -> String {
    let lines: array<String>;
    switch ev {
      case SingEvent.ModeSwitch:
        if Equals(this.m_mode, SingMode.Stealth) {
          lines = ["Ghost protocol engaged. We were never here."];
        } else if Equals(this.m_mode, SingMode.Defense) {
          lines = ["Shields up. Nobody touches you."];
        } else {
          lines = ["Offense online. Let's make some noise."];
        };
        break;
      case SingEvent.Kill:
        if Equals(this.m_mode, SingMode.Stealth) {
          lines = ["Clean. Quiet. I like it.", "One less problem."];
        } else if Equals(this.m_mode, SingMode.Defense) {
          lines = ["Threat down. Stay behind cover.", "Still breathing? Good."];
        } else {
          lines = ["Flatlined!", "Next one, choom.", "Boom. Beautiful."];
        };
        break;
      case SingEvent.Idle:
        lines = ["You ever think about how many cameras are watching us right now?",
                 "Quiet night. Suspiciously quiet.",
                 "I could hack a vending machine just for fun."];
        break;
    }
    if ArraySize(lines) == 0 {
      return "";
    };
    return lines[RandRange(0, ArraySize(lines))];
  }
  private func Say(text: String) -> Void {
    if !this.IsInstalled() {
      return;
    };

    let msg: SimpleScreenMessage;
    msg.isShown = true;
    msg.message = "S.I.N.G: " + text;
    msg.duration = 4.0;

    let bb = GameInstance.GetBlackboardSystem(this.GetGameInstance())
      .Get(GetAllBlackboardDefs().UI_Notifications);

    bb.SetVariant(
      GetAllBlackboardDefs().UI_Notifications.OnscreenMessage,
      ToVariant(msg),
      true
    );
  }

  // idle chatter: re-arms itself with a random delay
  public func StartIdleLoop() -> Void {
    if this.m_idleRunning {
      return;
    };
    this.m_idleRunning = true;
    this.ScheduleIdle();
  }

  private func ScheduleIdle() -> Void {
    GameInstance.GetDelaySystem(this.GetGameInstance())
      .DelayCallback(new SingIdleCallback(), RandRangeF(45.0, 120.0), false);
  }

  public func OnIdleTick() -> Void {
    this.Trigger(SingEvent.Idle, false);
    this.ScheduleIdle();
  }

  // ===== JOB SYSTEM =====

  public func StartJob(target: ref<GameObject>, kind: SingJobKind, duration: Float) -> Bool {
    if !IsDefined(target) {
      return false;
    };
    // don't start a second job on the same target
    let i = 0;
    while i < ArraySize(this.m_jobs) {
      if IsDefined(this.m_jobs[i].target) && Equals(this.m_jobs[i].target.GetEntityID(), target.GetEntityID()) {
        return false;
      };
      i += 1;
    };

    let job = new SingJob();
    job.id = this.m_nextJobId;
    job.target = target;
    job.kind = kind;
    this.m_nextJobId += 1;
    ArrayPush(this.m_jobs, job);

    let cb = new SingJobCallback();
    cb.jobId = job.id;
    GameInstance.GetDelaySystem(this.GetGameInstance()).DelayCallback(cb, duration, false);

    this.Say("Hacking " + this.KindName(kind) + "...");
    return true;
  }

  public func CompleteJob(jobId: Int32) -> Void {
    let job = this.TakeJob(jobId);
    if !IsDefined(job) {
      return;
    };
    // cancel if the target is gone or you walked out of range
    if !IsDefined(job.target) || !this.InRange(job.target) {
      this.Say("Lost the connection. Moving on.");
      return;
    };

    if this.ApplyEffect(job) {
      this.Say(this.KindName(job.kind) + " done.");
    } else {
      this.Say("Already handled. Moving on.");
    };
  }

  private func TakeJob(jobId: Int32) -> ref<SingJob> {
    let i = 0;
    while i < ArraySize(this.m_jobs) {
      if this.m_jobs[i].id == jobId {
        let job = this.m_jobs[i];
        ArrayErase(this.m_jobs, i);
        return job;
      };
      i += 1;
    };
    return null;
  }

  private func InRange(target: ref<GameObject>) -> Bool {
    let player = GameInstance.GetPlayerSystem(this.GetGameInstance()).GetLocalPlayerMainGameObject();
    if !IsDefined(player) {
      return false;
    };
    return Vector4.Distance(player.GetWorldPosition(), target.GetWorldPosition()) <= this.m_maxRange;
  }

  private func KindName(kind: SingJobKind) -> String {
    switch kind {
      case SingJobKind.OpenDoor: return "door";
      case SingJobKind.DisableCamera: return "camera";
      case SingJobKind.MemoryWipe: return "mind wipe";
    }
    return "target";
  }

  // test helper: starts a 3s camera job on whatever you're looking at
  public func TestJob() -> Void {
    let player = GameInstance.GetPlayerSystem(this.GetGameInstance()).GetLocalPlayerMainGameObject();
    let target = GameInstance.GetTargetingSystem(this.GetGameInstance()).GetLookAtObject(player);
    if !this.StartJob(target, SingJobKind.DisableCamera, 3.0) {
      this.Say("Nothing to hack there.");
    };
  }

  // ===== RADIUS SCAN =====

  // finds hackable things around the player and starts a job on each
  public func ScanNearby() -> Int32 {
    let game = this.GetGameInstance();
    let player = GameInstance.GetPlayerSystem(game).GetLocalPlayerMainGameObject();

    let query = TSQ_ALL();
    query.maxDistance = this.m_scanRadius;
    query.filterObjectByDistance = true;

    let parts: array<TS_TargetPartInfo>;
    GameInstance.GetTargetingSystem(game).GetTargetParts(player, query, parts);

    let started = 0;
    let i = 0;
    while i < ArraySize(parts) && ArraySize(this.m_jobs) < this.m_maxJobs {
      let obj = TS_TargetPartInfo.GetComponent(parts[i]).GetEntity() as GameObject;
      let kind: SingJobKind;
      if IsDefined(obj) && this.ClassifyTarget(obj, kind) {
        if this.StartJob(obj, kind, 2.5) {
          started += 1;
        };
      };
      i += 1;
    };
    return started;
  }

  // decides what S.I.N.G does to a given object (returns false = ignore it)
  private func ClassifyTarget(obj: ref<GameObject>, out kind: SingJobKind) -> Bool {
    if IsDefined(obj as SurveillanceCamera) {
      if !this.IsCameraOn(obj) {
        return false;
      };
      kind = SingJobKind.DisableCamera;
      return true;
    };
    if IsDefined(obj as Door) {
      kind = SingJobKind.OpenDoor;
      return true;
    };
    return false;
  }

  // ===== EFFECTS =====

  // true only if the device exists and is currently powered on
  private func IsCameraOn(obj: ref<GameObject>) -> Bool {
    let device = obj as Device;
    if !IsDefined(device) {
      return false;
    };
    return device.GetDevicePS().IsON();
  }

  // returns true if an effect was actually applied
  private func ApplyEffect(job: ref<SingJob>) -> Bool {
    switch job.kind {
      case SingJobKind.DisableCamera:
        if !this.IsCameraOn(job.target) {
          return false;
        };
        this.RunDeviceAction(job.target, n"ToggleON");
        return true;
      case SingJobKind.OpenDoor:
        this.RunDeviceAction(job.target, n"ToggleOpen");
        return true;
    }
    return false;
  }

  // runs a device action by name, the same route quickhacks use
  private func RunDeviceAction(target: ref<GameObject>, actionName: CName) -> Void {
    let device = target as Device;
    if !IsDefined(device) {
      return;
    };
    let ps = device.GetDevicePS();
    let action = ps.GetActionByName(actionName) as ScriptableDeviceAction;
    if IsDefined(action) {
      ps.ExecutePSAction(action, ps);
    } else {
      this.Say("No action named " + NameToString(actionName));
    };
  }
}

// === TRIGGER HOOKS ===

// Kill trigger: fires when the player kills an NPC
@wrapMethod(NPCPuppet)
protected cb func OnDeath(evt: ref<gameDeathEvent>) -> Bool {
  let result = wrappedMethod(evt);
  if IsDefined(evt.instigator) && evt.instigator.IsPlayer() {
    SingSystem.Get(this.GetGame()).Trigger(SingEvent.Kill, false);
  };
  return result;
}

// Start the idle loop once the player spawns
@wrapMethod(PlayerPuppet)
protected cb func OnGameAttached() -> Bool {
  let result = wrappedMethod();
  SingSystem.Get(this.GetGame()).StartIdleLoop();
  return result;
}
